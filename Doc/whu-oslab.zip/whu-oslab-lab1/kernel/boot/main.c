#include "riscv.h"
#include "lib/print.h"

volatile static int started = 0;

int main()
{
    while (1);    
}