/* memory leyout */
#ifndef __MEMLAYOUT_H__
#define __MEMLAYOUT_H__

// UART 相关
#define UART_BASE  0x10000000ul
#define UART_IRQ   10

// 内核基地址
#define KERNEL_BASE 0x80000000ul

#endif